#include <iostream>
using namespace std;

// Realizado por Mayoni

int main() {
    int tabletas, laptops;
    int totalUnidades, gananciaTotal;
    const int precioTableta = 4000;
    const int precioLaptop = 7000;

    cout << "Ingrese el número total de unidades vendidas: ";
    cin >> totalUnidades;
    cout << "Ingrese la ganancia total obtenida: ";
    cin >> gananciaTotal;

    if (gananciaTotal < totalUnidades * precioTableta || gananciaTotal > totalUnidades * precioLaptop) {
        cout << "Datos no válidos. Verifique los valores ingresados." << endl;
        return 1;
    }

    laptops = (gananciaTotal - (precioTableta * totalUnidades)) / (precioLaptop - precioTableta);
    tabletas = totalUnidades - laptops;

    if (laptops < 0 || tabletas < 0) {
        cout << "Error en el cálculo. Datos no permiten una solución viable." << endl;
        return 1;
    }

    cout << "Se vendieron " << tabletas << " tabletas y " << laptops << " laptops ese día." << endl;

    return 0;
}
